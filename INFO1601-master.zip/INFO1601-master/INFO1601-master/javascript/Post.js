function myFunction() {
    alert("Thank you for the submission!");
}